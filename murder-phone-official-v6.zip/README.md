# Murder Phone — Original Edition (v6) APK Project

Supports all three ways to play while preserving 100% of the official Spin Master Murder Phone rules, composition notebook theme, original artwork, zero emojis, and one-time secret role reveal:

1. **Act as the Murder Phone (Both on 1 Phone):** Pass one phone around the table with built-in privacy shields for roles, room search codes, Casey calls, and secret votes—with the Cabin Map & Time Track right on the same screen.
2. **2-Device Tabletop Mode (Murder Phone + Separate Table Map Phone):** One phone acts as the SM194 Murder Phone and generates a 4-letter **Map Sync Code**; a second phone/tablet joins as the live **Table Map** in the center of the table (never leaking secret roles or private calls).
3. **Multi-Phone Mode (1 Phone per Player):** Every player connects on their own phone via a 4-letter Cabin Room Code.

## Build Your APK (GitHub Actions)
1. Upload all unzipped files (including `www/assets/` and `.github/workflows/build-apk.yml`) to a GitHub repository.
2. Open the **Actions** tab and wait ~2 minutes for **Build Android APK** to finish.
3. Download **`murder-phone-original-v6-apk`** (`app-debug.apk`).
